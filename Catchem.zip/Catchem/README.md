<p align="center"><a href="https://github.com/Lunat1q/Catchem-PoGo/wiki"><img src="https://i.imgur.com/wittUbf.png" /></a></p>
<p align="center">:information_source:This project is for education purposes only:information_source:</p>
<p align="center">Based on PokeMobBot Project</p>
</p>

<p align="center"><a href="https://discord.gg/pPwxX8Q"><img src="https://discordapp.com/api/guilds/212977806819196938/widget.png?style=banner2"/></a></p>
<p align="center"><img src="https://img.shields.io/github/downloads/Lunat1q/Catchem-PoGo/total.svg"/><a href="https://github.com/Lunat1q/Catchem-PoGo/releases/latest"><img src="https://img.shields.io/github/downloads/Lunat1q/Catchem-PoGo/latest/total.svg"/></a></p>

<p align="center">THERE IS ONLY <b>ONE</b> OFFICIAL <a href="https://discord.gg/pPwxX8Q">DISCORD SERVER</a></p>

<h2>Download</h2>
You can download this bot  <a href="https://github.com/Lunat1q/Catchem-PoGo/releases/latest">HERE</a>

<h2>OpenSource</h2>
This project will not provide source code for everyone anymore, due to it being stolen and being sold.<br/>
We will continue to develop this project, absolutely the same as i did before.<br/>
However Source Code  will not be published anymore.<br/>
We will still continue to release compiled updates (on release tab as it was before) of this software, so this will not effect most of our users.<br/>
If you'll need source codes, or part of them, contact me in <a href="https://discord.gg/pPwxX8Q">Discord</a>.

<h2>Donating</h2>
If you really like this project, feel free to buy <b>pizza</b> :pizza: or :beers: for devs (or a present :rose: :gift: for my gf, she is a bit mad that i'm spending most part of my free time for this project :coffee:):<br/><br/>
<p align="center"><a href="https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=RFAU4PYCAAGML"><img src="https://www.paypalobjects.com/en_US/GB/i/btn/btn_donateCC_LG.gif"/></a></p>
<p align="center"><img src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/46/Bitcoin.svg/64px-Bitcoin.svg.png"/>BitCoin: 1LTQdD6cnxhqSAYyNAa7PpcfSu6uCmxrdn</p>
###We really appreciate all the donations made, so everyone who donated to our project will get access to privileged support channel!
#####If you don't have PayPal account but still want to donate for my work, Please contact me in Discord :)

##See it in action:
<p align="center"><a href="https://www.google.com/search?ie=UTF-8&q=Catchem&gws_rd=ssl#q=Catchem&newwindow=1&tbm=vid"><img src="http://i.imgur.com/3NzF9iV.png"/></a></p>

<h2>Extra features (from PokeMobBot) project)</h2>

 - [Discovery pathing function -> bot continue to walk in radom direction from pokestop to pokestop, it pick closest pokestop each turn!]
 - [Detailed info for every Poke you have]
 - [CustomRoute feature! You can create custom routes right from UI]
 - [Manual Transfer/Favorite/Evolve/LevelUp/Recycle from UI!]
 - [Batch creation of accounts]
 - [Bot schedule! Set desired working time for every day of the week!]
 - [Force move option, just double click to the map and bot will start moving there!]
 - [Proxy support]
 - [All settings from UI]
 - [You can set startup location from the map, just select the bot (don't hit Start), go to the map tab, and just double-click to desired position]
 - [Full controll of your inventory/poke]
 - [Smooth controll of movement speed on the run via MoveSpeedFactor slider]
 - [Make map follow your player]

<br/>
<h2>Screenshots</h2>
![Map/Console tab](http://i.imgur.com/UD0hc2B.png)<br/>

 
Get Device data from real android device:
 1. [Enable USB debugging at your phone settings]
 2. [Ensure what your PC have proper ADB drivers installed]
 3. [Click "Get Data from Your Android Phone" button at the Settings tab - you are awesome]
 <br/><br/>
If you have any problems with getting device info, consider watching this post: [AdbDrivers](http://forum.xda-developers.com/showthread.php?p=48915118#post48915118)

<h2>Credits</h2>
Thanks to Feroxs' hard work on the API & Console we are able to manage something like this.
Without him, this would not have been available.</br>
Design ideas: <i><b>[@Morphir](https://github.com/ephran)</b> - Poke info design</i>, <i><b>Su**ro</b> - initial design idea</i>

 
 
 <h2>Rights</h2>
 All rights to trademarks used are going to Nintendo and Niantic 


<h2>Licence</h2>
Licenced under AGPLv3
