##Greetings!
1. Please, read [WIKI](https://github.com/Lunat1q/Catchem-PoGo/wiki) and search your question in the [closed issues](https://github.com/Lunat1q/Catchem-PoGo/issues?q=is%3Aissue+is%3Aclosed), use searchbox at the top.
2. Consider to join Discord, instead of writing your quesion in the issues. [>>>JOIN DISCORD<<<](https://discord.gg/pPwxX8Q)
3. Check the #roadmap channel in discord, before suggesting anything, or don't be surprised when your issue will be closed with no explanation
